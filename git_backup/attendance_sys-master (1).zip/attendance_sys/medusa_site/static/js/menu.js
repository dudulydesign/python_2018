<script>
  var myCollection = document.getElementsByTagName("p");
  document.getElementById("content").innerHTML =
  "" + myCollection[1].innerHTML;
</script>

