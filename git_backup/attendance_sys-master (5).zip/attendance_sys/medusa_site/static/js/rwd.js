<script type='text/javascript'>
  $("#content").resizable();
</script>
